PepeCoin (PEPE)
===============
-------------------------------------------
A Hybrid Proof of Work / Proof of Stake / Pepe Stake Rate Cryptocurrency


 - Default port 29377 and RPC port 29376

 - 60 seconds block time POW
 - ~3 Months Proof of Work mining distribution ~16m PEPE
 - X11 mining algorithm
 - Pepe Stake Rate PSR / POS enable at block 9000
 - POW End at block 130420

 - 40 confirmations for newly Proof of Work mined blocks
 - 100 confirmations for newly Proof of Stake minted blocks
 - 3.5% Premine for Development Fund - Public Ledger and Transparent

  POSV Details
 ------------
  - Proof of Stake activates at block 9000.
  - 60 seconds per block time Proof of Stake
  - 6 hour minimum stake age
  - Additional security improvements
  - Staking rewards are variable depending on the number of PEPE held (below)

10% of stake, Masternodes Payouts begin 04 14 2016 0600

PEPE Masternodes can stake coins that are held in MN.

-------------------------------------------

Pepecoin X11 Proof of Work Block Reward Schedule
------------------------------------------------
```
Block   1 - 99 - PEPE Development Fund and Checkpointing

* Block 100 Public Launch *

Block	100	 to 	900	 - 	1500	 PEPE
Block	900	 to 	1300	 - 	1200	 PEPE
Block	1300	 to 	1900	 - 	1050	 PEPE
Block	1900	 to 	2900	 - 	900	 PEPE
Block	2900	 to 	4100	 - 	750	 PEPE
Block	4100	 to 	6680	 - 	600	 PEPE
Block	6680	 to 	9260	 - 	400	 PEPE
Block	9260	 to 	11840	 - 	500	 PEPE
Block	11840	 to 	14420	 - 	200	 PEPE
Block	14420	 to 	17000	 - 	300	 PEPE
Block	17000	 to 	19580	 - 	100	 PEPE
Block	19580	 to 	22160	 - 	200	 PEPE
Block	22160	 to 	24740	 - 	90	 PEPE
Block	24740	 to 	27320	 - 	130	 PEPE
Block	27320	 to 	29900	 - 	80	 PEPE
Block	29900	 to 	32480	 - 	100	 PEPE
Block	32480	 to 	35060	 - 	70	 PEPE
Block	35060	 to 	37640	 - 	100	 PEPE
Block	37640	 to 	40220	 - 	60	 PEPE
Block	40220	 to 	42800	 - 	100	 PEPE
Block	42800	 to 	45380	 - 	50	 PEPE
Block	45380	 to 	47960	 - 	100	 PEPE
Block	47960	 to 	50540	 - 	40	 PEPE
Block	50540	 to 	53120	 - 	100	 PEPE
Block	53120	 to 	55700	 - 	40	 PEPE
Block	55700	 to 	58280	 - 	100	 PEPE
Block	58280	 to 	60860	 - 	40	 PEPE
Block	60860	 to 	63440	 - 	100	 PEPE
Block	63440	 to 	66020	 - 	40	 PEPE
Block	66020	 to 	68600	 - 	100	 PEPE
Block	68600	 to 	71180	 - 	40	 PEPE
Block	71180	 to 	73760	 - 	90	 PEPE
Block	73760	 to 	76340	 - 	30	 PEPE
Block	76340	 to 	78920	 - 	80	 PEPE
Block	78920	 to 	81500	 - 	30	 PEPE
Block	81500	 to 	84080	 - 	70	 PEPE
Block	84080	 to 	86660	 - 	30	 PEPE
Block	86660	 to 	89240	 - 	60	 PEPE
Block	89240	 to 	91820	 - 	30	 PEPE
Block	91820	 to 	94400	 - 	50	 PEPE
Block	94400	 to 	96980	 - 	30	 PEPE
Block	96980	 to 	99560	 - 	50	 PEPE
Block	99560	 to 	102140	 - 	30	 PEPE
Block	102140	 to 	104720	 - 	50	 PEPE
Block	104720	 to 	107300	 - 	20	 PEPE
Block	107300	 to 	109880	 - 	40	 PEPE
Block	109880	 to 	112460	 - 	20	 PEPE
Block	112460	 to 	115040	 - 	30	 PEPE
Block	115040	 to 	117620	 - 	20	 PEPE
Block	117620	 to 	120200	 - 	25	 PEPE
Block	120200	 to 	122780	 - 	15	 PEPE
Block	122780	 to 	125360	 - 	20	 PEPE
Block	125360	 to 	127940	 - 	15	 PEPE
Block	127940	 to 	130420	 - 	20	 PEPE

								TOTAL


								16066300


POW End Block 130420 Approx 3 Months

Total from 1 Yr. POW: 16,066,300 PEPE

3.5% Development fund: 562,390 PEPE

Total PEPE in POW & Fund: 16,628,690 PEPE




```


Pepe Stake Rate (PSR) %  POSV Reward Schedule
---------------------------------

| PEPE Amount    | Stake % Year 1|  Year 2  |  Year 3+ |
|:-------------|:-------------:|------------:|------------:|
 |0 to 10000    |    3.0%|  2.0% | 1.0% |
 |10,000+        |    4.0%| 3.0% | 2.0% |
 |50,000+        |    5.0%|4.0%|3.0%|
 |100,000+       |    6.0%|5.0%|4.0%|


----------------------------------


Proof of Sadfrog (POSF)
----------------
 - Security improved open source "Fair-Weight" Proof of Sadfrog protocol technology

 - Coin holders benefit from multiple block stakes and are rewarded for running regularly as a node.

 - Proof of Sadfrog also  keeps the network alive by slowing coin age after 1 month with an aging half life of 90 days. Keep the magic alive.

 - PepeLife technology ensures PEPE holders contribute to the health of the network at least once each month to earn the highest possible rewards, and incentivises running full nodes and/or keeping wallets open to increase PEPE network security.

 -------------------------------

Additional Information
------------------------------
PepeCoin uses libsecp256k1, libgmp, Boost1.55, OR Boost1.57, Openssl1.01p, Berkeley DB 4.8, QT5 to compile

```

Copyright (c) 2009-2010 Satoshi Nakamoto
Copyright (c) 2009-2012 The Bitcoin developers
Copyright (c) 2012 Litecoin Developers
Copyright (c) 2013 Peercoin Developers
Copyright (c) 2014 DarkCoin Developers
Copyright (c) 2014 BlackCoin Developers
Copyright (c) 2014 Digibyte Developers
Copyright (c) 2014 DashCoin Developers
Copyright (c) 2014 NetCoin Developers
Copyright (c) 2015 Transfercoin Developer
Copyright (c) 2015-2016 PepeCoin Developers

 ```

![alt text](http://i2.kym-cdn.com/photos/images/newsfeed/000/095/218/feels-good-man.jpg "Pepe approves")
