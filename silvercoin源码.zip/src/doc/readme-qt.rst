pepecoin-qt: Qt5 GUI for PepeCoin
===============================

Linux
-------
https://gitlab.com/pepecoin/blob/master/doc/build-unix.md

Windows
--------
https://gitlab.com/pepecoin/blob/master/doc/build-msw.md

Mac OS X
--------
https://gitlab.com/pepecoin/blob/master/doc/build-osx.md
