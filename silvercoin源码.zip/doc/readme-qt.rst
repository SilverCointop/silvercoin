SilverCoin-qt: Qt5 GUI for SilverCoin
===============================

Linux
-------
https://gitlab.com/SilverCoin/blob/master/doc/build-unix.md

Windows
--------
https://gitlab.com/SilverCoin/blob/master/doc/build-msw.md

Mac OS X
--------
https://gitlab.com/SilverCoin/blob/master/doc/build-osx.md
